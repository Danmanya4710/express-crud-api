# Simple Express CRUD API

This project is a RESTful API built with Node.js and Express that supports full CRUD operations using an in-memory array.

## Features
- GET all items
- GET one item by ID
- POST new item
- PUT update item by ID
- DELETE item by ID

## How to Run
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the server:
   ```bash
   node server.js
   ```

Server runs on `http://localhost:3000`
